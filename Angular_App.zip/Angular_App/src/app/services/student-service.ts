import { inject, Service } from '@angular/core';
import { map, Observable, of } from 'rxjs';
import { Student } from '../Models/student';
import { HttpClient } from '@angular/common/http';

@Service()
export class StudentService {

  private http = inject(HttpClient);

  public apiUrl = 'https://localhost:44337';


  getStudents() {
    return this.http.get<{ students: Student[] }>('https://localhost:44337/api/Student/getall');
  }

  CreateUser(student: Student) {
    return this.http.post(
      'https://localhost:44337/api/Student',
      student
    );
  }

  DeleteUser(student_id: number) {
    return this.http.delete(
      `https://localhost:44337/api/Student/${student_id}`
    ).pipe(
      map((data: any) => {
        return data;
      })
    );
  }

  UpdateUser(student_id: number, student: Student) {
    return this.http.put(
      `https://localhost:44337/api/Student/${student_id}`,
      student
    );
  }

}
