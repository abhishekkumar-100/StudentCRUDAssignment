import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import Swal from 'sweetalert2';
import { StudentService } from '../services/student-service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-createuser',
  imports: [ReactiveFormsModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule],
  templateUrl: './createuser.component.html',
  styleUrl: './createuser.component.css',
})
export class CreateuserComponent {


  studentForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private studentService: StudentService,
    private router: Router
  ) {

    this.studentForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      course: ['', Validators.required]
    });

  }

  saveStudent() {

    const payload = this.studentForm.value;

    this.studentService.CreateUser(payload).subscribe({
      next: (res: any) => {

        Swal.fire({
          icon: 'success',
          title: 'Success',
          text: res.message
        }).then(() => {
          this.router.navigate(['/']);
        });

      },
      error: (err) => {

        Swal.fire({
          icon: 'error',
          title: 'Error',
          text: err?.error?.message || 'Failed to create student'
        });

      }
    });
  }


}





