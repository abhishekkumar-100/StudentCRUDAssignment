import { Component, inject } from '@angular/core';
import { StudentService } from '../services/student-service';
import { Student } from '../Models/student';
import { MatCardModule } from '@angular/material/card';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { RouterLink } from "@angular/router";
import Swal from 'sweetalert2';
import { window } from 'rxjs';

@Component({
  selector: 'app-student-component',
  imports: [CommonModule, MatTableModule, MatCardModule, MatIconModule,
    MatButtonModule, RouterLink],
  templateUrl: './student-component.html',
  styleUrl: './student-component.css',
})
export class StudentComponent {


  private studentService = inject(StudentService);

  displayedColumns: string[] = ['id', 'name', 'email', 'course', 'actions'];

  student = new MatTableDataSource<Student>([]);

  constructor() {
    this.studentService.getStudents().subscribe(data => {

    });
  }


  ngOnInit(): void {
    // const data = localStorage.getItem('students');
    // if (data) {
    //   this.student = JSON.parse(data);
    // }

    this.loadStudents();
  }
  loadStudents() {
    this.studentService.getStudents().subscribe(res => {
      this.student.data = res.students;   // ✅ correct
      console.log(this.student);
    });
  }


  deleteStudent(_studeid: number) {
    this.studentService.DeleteUser(_studeid).subscribe((res) => {
      Swal.fire({
        title: 'Are you sure?',
        text: 'You will not be able to recover this student!',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Yes, Delete it!'
      }).then((result) => {

        if (result.isConfirmed) {
          // Call Delete API Here
          Swal.fire({
            icon: 'success',
            title: 'Deleted!',
            text: 'Student has been deleted.'

          }).then(() => {
            this.loadStudents();
          });;
        }

      })

    })


  }
}
