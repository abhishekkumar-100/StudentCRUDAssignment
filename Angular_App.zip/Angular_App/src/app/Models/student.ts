export class Student {

  id: number | undefined;
  name: string | undefined;
  email: string | undefined;
  course: string | undefined;


}
