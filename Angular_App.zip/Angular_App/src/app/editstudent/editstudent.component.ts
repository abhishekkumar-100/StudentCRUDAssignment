import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { Student } from '../Models/student';
import { StudentService } from '../services/student-service';
import Swal from 'sweetalert2';
import { MatInputModule } from '@angular/material/input';

@Component({
  selector: 'app-editstudent',
  imports: [CommonModule,
    ReactiveFormsModule,
    MatCardModule,
    MatButtonModule,
    MatInputModule,
    MatFormFieldModule
  ],
  templateUrl: './editstudent.component.html',
  styleUrl: './editstudent.component.css',
})
export class EditstudentComponent {

  studentForm!: FormGroup;
  studentId!: number;

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute, private studentservice: StudentService
  ) { }


  ngOnInit() {
    const student = history.state.student;
    console.log("rrra", history.state.student.id);
    this.studentForm = student;
    this.studentId = Number(
      this.route.snapshot.paramMap.get('id')
    );


    this.studentForm = this.fb.group({
      name: [student?.name || ''],
      email: [student?.email || ''],
      course: [student?.course || '']
    });
    // API Call Here
    // GET /api/students/{id}
  }


  get name() {
    return this.studentForm.controls['name'];
  }

  updateStudent() {

    const payload = this.studentForm.value;

    this.studentservice.UpdateUser(
      history.state.student.id,
      payload
    ).subscribe({
      next: (res: any) => {

        Swal.fire({
          icon: 'success',
          title: 'Success',
          text: res.message || 'Student updated successfully!'
        });

      },
      error: (err) => {

        Swal.fire({
          icon: 'error',
          title: 'Error',
          text: err?.error?.message || 'Failed to update student!'
        });

        console.error(err);
      }
    });
  }
}