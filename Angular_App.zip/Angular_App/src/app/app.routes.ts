import { Routes } from '@angular/router';
import { StudentComponent } from './student-component/student-component';
import { EditstudentComponent } from './editstudent/editstudent.component';
import { CreateuserComponent } from './createuser/createuser.component';

export const routes: Routes = [
  {
    path: '',
    component: StudentComponent
  },
  {
    path: 'editstudent',
    component: EditstudentComponent
  },
    {
    path: 'adduser',
    component:  CreateuserComponent
  }

];
